Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: "name",
    kind: "kind",
    indication: "indication",
    Usage: "Usage and dosage",
    Adverse_Reactions: "Adverse reactions",
    matters: "matters",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const db = wx.cloud.database() //获取数据库的引用
    const _ = db.command //获取数据库查询及更新指令
    db.collection("medicine") //获取集合china的引用
      .where({ //查询的条件指令where
        name: _.eq("达克宁"),
      })
      .skip(0) //跳过多少个记录（常用于分页），0表示这里不跳过
      .limit(10) //限制显示多少条记录，这里为10
      .get() //获取根据查询条件筛选后的集合数据
      .then(res => {
        console.log(res.data)
        this.setData({
          name: res.data[0].name,
          kind: res.data[0].kind,
          indication: res.data[0].guide.适应症,
          Usage: res.data[0].guide.用法用量,
          Adverse_Reactions: res.data[0].guide.不良反应,
          matters: res.data[0].guide.注意事项
        })
      })
      .catch(err => {
        console.error(err)
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})