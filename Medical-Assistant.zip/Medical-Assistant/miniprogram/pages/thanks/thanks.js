Page({

  /**
   * 页面的初始数据
   */
  data: {
    height: 20,
    focus: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  bindFormSubmit: function (e) {
    console.log(e.detail.value.textarea)
    var suggestion = e.detail.value.textarea
    const db = wx.cloud.database() //获取数据库的引用
    const _ = db.command //获取数据库查询及更新指令
    db.collection('opinion').add({
        data: {
          suggestions: suggestion
        }
      })
      .then(res => {
        console.log(res)
        wx.showToast({
          title: '提交成功！谢谢您的意见！',
          icon: 'success',
          duration: 1000
        })
      })
  },
})