// pages/hospitical/hospitical.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [
      'cloud://menofletters-51imr.6d65-menofletters-51imr-1302633453/hospitical/d4cecdbb5f10d63d87efbf132cc29523.jpg',
      'cloud://menofletters-51imr.6d65-menofletters-51imr-1302633453/hospitical/6626e557fa9c176917e1da1257966298.jpg',
      'cloud://menofletters-51imr.6d65-menofletters-51imr-1302633453/hospitical/1772e9fad5f9f8fda01454c8800b8c12.jpeg'
    ],
    interval: 2500,
    duration: 1000,
    indicatorDots: true,
    indicatorColor: "#ffffff",
    activecolor: "#2971f6",
    autoplay: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})